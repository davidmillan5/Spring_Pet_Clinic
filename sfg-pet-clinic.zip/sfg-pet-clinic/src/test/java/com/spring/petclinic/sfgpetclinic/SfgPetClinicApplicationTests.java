package com.spring.petclinic.sfgpetclinic;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SfgPetClinicApplicationTests {

	@Test
	void contextLoads() {
	}

}
